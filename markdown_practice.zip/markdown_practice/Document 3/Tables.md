# Table 1

| Id  | Name            | Email                   | Investments          |
| --- | --------------- | ----------------------- | -------------------- |
| 231 | Albert Master   | albert.master@gmail.com | Bonds                |
| 210 | Alfred Alan     | aalan@gmail.com         | Stocks               |
| 256 | Alison Smart    | asmart@biztalk.com      | Residential Property |
| 211 | Ally Emery      | allye@easymail.com      | Stocks               |
| 248 | Andrew Phips    | andyp@mycorp.com        | Stocks               |
| 234 | Andy Mitchel    | andym@hotmail.com       | Stocks               |
| 226 | Angus Robins    | arobins@robins.com      | Bonds                |
| 241 | Ann Melan       | ann_melan@iinet.com     | Residential Property |
| 225 | Ben Bessel      | benb@hotmail.com        | Stocks               |
| 235 | Bensen Romanoff | benr@albert.net         | Bonds                |

# Table 2

| Letter Grade | Percentage  |
| ------------ | ----------- |
| A            | 90 – 100%   |
| B            | 80 – 89.99% |
| C            | 70 – 79.99% |
| D            | 60 – 69.99% |
| F            | < 60%       |

# Table 3

| Part                            | Name        |
| ------------------------------- | ----------- |
| ![gpu](gpu.png)                 | gpu         |
| ![hard-disk](hard-disk.png)     | hard-disk   |
| ![motherboard](motherboard.png) | motherboard |
| ![ram](ram.png)                 | ram         |