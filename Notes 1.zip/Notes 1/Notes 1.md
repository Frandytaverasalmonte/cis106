# Notes 1
## What is Markdown?
**Markdown** is a lightweight markup language that you can use to add formatting elements to plaintext text documents.  Created by John Gruber in 2004, Markdown is now one of the world’s most popular markup language. 

## What is Git?
**Git** is a version control system that helps you track changes in your files over time. In simple terms, Git is like a save history button for your projects.

## What is GitHub?
**GitHub** is an online platform where people store, manage, and work together on code and projects. In simple terms, it’s like Google Drive for code, but with powerful tools for tracking changes and collaborating.

## What is Slack?
**Slack** is a communication and collaboration app used by teams to talk and work together in one place. In simple terms, Slack is like WhatsApp or Discord for school and work, but more organized.